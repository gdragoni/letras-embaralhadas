//
//  GeradorDePalavrasAleatorias.h
//  PalavrasEmbaralhadas
//
//  Created by Gabriel A. Dragoni on 5/11/16.
//  Copyright © 2016 Gabriel A. Dragoni. All rights reserved.
//

#include "Constant.h"

enum Tema : int{            /*enum com temas possiveis*/
    NomeProprio,
    Animal,
    Veiculo,
    Comida,
    erro
};

class GeradorDePalavrasAleatorias{    
public:
    string palavraAleatoria(Tema tema); /*retorna palavra aleatoria por tema*/
};

