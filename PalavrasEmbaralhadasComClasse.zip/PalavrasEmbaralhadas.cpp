//
//  main.cpp
//  LetrasEmbaralhadas
//
//  Created by Gabriel A. Dragoni on 3/15/16.
//  Copyright © 2016 Gabriel A. Dragoni. All rights reserved.
//

#include <iostream>                             /*biblioteca cout e cin*/
#include <cstring>                              /*biblioteca para string*/
#include <stdio.h>                              /* printf, NULL */
#include <stdlib.h>                             /* srand, rand */
#include <time.h>                               /* time */
#include "PalavrasAleatorias.hpp"               /*Classe que fornece palavras*/

//macro para flexibilidade do codigo//
#define QTD_DE_PALAVRAS 20                       /* Maximo de quantidade de palavras cadastradas no jogo (20) */

using namespace std;

//variaveis publicas da classe//
char matrizDePalavras[QTD_DE_PALAVRAS+1][16];     /*matriz com QUANTIDADEDEPALAVRASx15 caracteres usaveis*/
string tema;                                      /*variável que armazena o tema escolhido*/
PalavrasAleatorias PalAleClass = PalavrasAleatorias();/*instancia da classe que fornece palavras aleatórias*/

//metodos//
void   carregarMatrizComPalavras();               /*metodo para carregar a matriz com as palavras aleatórias*/
void   mostrarPalavra(string palavraEmbaralhada); /*mostra (cout) palavra com design definido*/
void   pulaLinha(int quantidadeDeLinhas);         /*metodo pra pular linhas*/
float  calcularPorcentagem (float numero, float total);/*calcula porcentagem*/
string palavraNoIndiceDaMatriz(int indice);       /*Recupera palavra na matriz com o indice passado como parametro*/
string palavraEmbaralhada(string palavra);        /*Embaralha a palavra passada como parametro*/
string palavraMaiuscula(string palavra);          /*Passa todas as letras da palavra para maiusculo*/
bool   testeTemaValido(string tema);              /*Teste para tema*/

int main(int argc, const char * argv[]) {
   
    string palavra;
    string palavraDigitada;
    int pontos = 0, rodada = 0;
    
    do{
        
        pulaLinha(1);
        cout << "Escolha um tema: ANIMAL, FRUTA, OBJETO, NOMES OU MISTURADO.\nTema: ";
        cin >> tema;
        tema = palavraMaiuscula(tema);
        
    }while (!testeTemaValido(tema));
    
    srand((unsigned)time(NULL));                /*atribuir o relogio para o srand, para que ele sorteie um numero diferente a cada rand() usado*/
    
    carregarMatrizComPalavras();
    
    for (int i = 0; i < QTD_DE_PALAVRAS; i++) {
        
        rodada++;
        palavra = palavraNoIndiceDaMatriz(i);
        
        pulaLinha(1);
        cout << "Rodada: " << rodada << "/"<<QTD_DE_PALAVRAS;
        pulaLinha(1);
        
        mostrarPalavra(palavraEmbaralhada(palavra));
        pulaLinha(2);
        cout << " Qual e a palavra ?";
        pulaLinha(1);
        
        cin >> palavraDigitada;
        
        palavraDigitada = palavraMaiuscula(palavraDigitada);
        
        pulaLinha(1);
        if (palavraDigitada == palavra) {
            
            pontos++;
            cout << " ACERTOU !!!";
            pulaLinha(2);
        }else{
            
            cout << "ERROU!!!";
            pulaLinha(2);
            cout << "Palavra Certa :";
            pulaLinha(1);
            mostrarPalavra(palavraNoIndiceDaMatriz(i));
            pulaLinha(1);
        }
        
        if (i != QTD_DE_PALAVRAS-1) {
            
            for (int j = 0; j < 40; j++) {
                
                cout << "#";
            }
            pulaLinha(2);
        }else{
            
            system("pause");
            int porcentagemInteira = calcularPorcentagem(pontos, QTD_DE_PALAVRAS);
            system("cls");

            mostrarPalavra("Pontuacao :");
            pulaLinha(2);
            cout << pontos << " palavras certas de "<< QTD_DE_PALAVRAS << "!";
            pulaLinha(2);
            
            cout << "Porcentagem de acertos : " << porcentagemInteira << "%";
            pulaLinha(2);
            
            if (porcentagemInteira > 80) {
                
                cout << "Parabens!!!";
            }else if (porcentagemInteira > 50){
                
                cout << "Ótimo!";
            }else if (porcentagemInteira > 30){
                
                cout << "Bom! Treine mais!";
            }else{
                
                cout << "Voce e burro demais, se mate";
            }
            
            system("pause");
            pulaLinha(2);
        }
    }
    
    return 0;
}

void carregarMatrizComPalavras(){
    
    string palavra;
    
    for (int i = 0; i < QTD_DE_PALAVRAS; i++) {
        
        palavra = PalAleClass.palavra(tema);
        
        for (int j = 0; j <= palavra.length(); j++) {
            
            matrizDePalavras[i][j] = palavra[j];
        }
    }
}

void mostrarPalavra(string palavraEmbaralhada){
    
    for (int i = 0; i < palavraEmbaralhada.length()*4; i++) {
        
        if (i == 0) {
            cout << "=";
        }
        cout << "=";
    }
    pulaLinha(1);
    for (int i = 0; i < palavraEmbaralhada.length(); i++) {
        
        if (i == 0) {
            
            cout << "| ";
        }
        
        cout << palavraEmbaralhada[i] << " | ";
    }
    pulaLinha(1);
    for (int i = 0; i < palavraEmbaralhada.length()*4; i++) {
        
        if (i == 0) {
            cout << "=";
        }
        cout << "=";
    }
}

void pulaLinha(int quantidadeDeLinhas){
    
    for (int i = 0; i < quantidadeDeLinhas; i ++) {
        
        cout << "\n";
    }
}

string palavraNoIndiceDaMatriz(int indice){
    
    string palavraNoIndice;
    
    for (int i = 0; i < 15; i++) {
        
        if (matrizDePalavras[indice][i] != '\0') {
            
            palavraNoIndice += matrizDePalavras[indice][i];
        }else{
            break;
        }
    }
    
    return palavraNoIndice;
}

string palavraMaiuscula(string palavra){
    
    string palavraMaiuscula;
    
    for (int i = 0; i < palavra.length(); i ++) {
        
        palavraMaiuscula += toupper(palavra[i]);
    }
    
    return palavraMaiuscula;
}

string palavraEmbaralhada(string palavra){
    
    string palavraEmbaralhada;
    
    for (int i = 0; i < palavra.length(); i ++) {
        
        int indice;
        
        do{
            indice = rand() % palavra.length();
            
        }while(palavra[indice] == '\0');
        
        palavraEmbaralhada += palavra[indice];
        palavra[indice] = '\0';
    }
    
    return palavraEmbaralhada;
}

bool testeTemaValido(string tema){
    
    if (tema == "ANIMAL" || tema == "FRUTA" || tema == "OBJETO" || tema == "NOME" || tema == "MISTURADO") {
        
        return true;
    }
    pulaLinha(2);
    cout << "Tema Invalido!";
    
    return false;
}

float calcularPorcentagem (float numero, float total) {
    
    float porcentagem = numero/total * 100;
    
    return porcentagem;
}