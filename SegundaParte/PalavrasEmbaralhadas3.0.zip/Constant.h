//
//  Constant.h
//  PalavrasEmbaralhadas
//
//  Created by Gabriel A. Dragoni on 5/11/16.
//  Copyright © 2016 Gabriel A. Dragoni. All rights reserved.
//

#include <iostream>             /*biblioteca cout e cin*/
#include <cstring>              /*biblioteca para string*/
#include <stdio.h>              /* printf, NULL */
#include <stdlib.h>             /* srand, rand */
#include <time.h>               /* time */

#define MAX_QTD_DE_PALAVRAS 20  /* Maximo de quantidade de palavras cadastradas no jogo (20) */
#define NOME_STRING "NOME"
#define COMIDA_STRING "COMIDA"
#define ANIMAL_STRING "ANIMAL"
#define VEICULO_STRING "VEICULO"

using namespace std;

